<?php get_header(); ?>
<main id="main-content">
  <section class="page-hero"><div class="container"><span class="eyebrow">Dot Edge Innovations Ltd</span><h1><?php the_archive_title(); ?></h1></div></section>
  <section class="section"><div class="container">
    <?php if (have_posts()): while(have_posts()): the_post(); ?>
      <article class="card" style="margin-bottom:18px"><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><?php the_excerpt(); ?></article>
    <?php endwhile; else: ?><p>No content found.</p><?php endif; ?>
  </div></section>
</main>
<?php get_footer(); ?>
