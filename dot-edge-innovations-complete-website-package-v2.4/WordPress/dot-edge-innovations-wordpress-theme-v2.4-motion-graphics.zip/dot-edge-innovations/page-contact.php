<?php get_header(); ?>
<main id="main-content">
<section class="page-hero"><div class="container"><span class="eyebrow">Start a Project</span><h1>Tell us what you want to build, improve, or automate.</h1><p>Share enough context for us to understand the opportunity. We can then explore the right solution for your business.</p></div></section>
<section class="section"><div class="container form-wrap">
<div class="prose"><h2>Let's talk about the problem.</h2><p>You can use this form for website development, app development, corporate branding, AI automation, AI video creation and editing, or other inquiries.</p><h2>What happens next?</h2><ul class="check-list"><li>We review the project brief.</li><li>We clarify the scope where needed.</li><li>We discuss an appropriate approach and next steps.</li></ul><p><strong>Note:</strong> email delivery uses the WordPress site administrator email until a dedicated verified receiving address is configured. Delivery has not been tested from this environment.</p></div>
<div class="form-card">
<?php if ($status=dot_edge_get_form_status()): ?><div class="notice <?php echo $status==='error'?'error':''; ?>"><?php echo $status==='success'?'Thanks — your inquiry was submitted. We will review it and follow up using the details provided.':'The form was received by the site, but email delivery could not be confirmed. Please check the WordPress mail configuration.'; ?></div><?php endif; ?>
<?php foreach(dot_edge_get_form_errors() as $error): ?><div class="notice error"><?php echo esc_html($error); ?></div><?php endforeach; ?>
<form method="post" action="">
<?php wp_nonce_field('dot_edge_contact','dot_edge_contact_nonce'); ?>
<div style="position:absolute;left:-9999px" aria-hidden="true"><label>Website<input name="website" tabindex="-1" autocomplete="off"></label></div>
<div class="form-row"><div class="field"><label for="full_name">Full name *</label><input required id="full_name" name="full_name" type="text" autocomplete="name"></div><div class="field"><label for="business_name">Business name</label><input id="business_name" name="business_name" type="text" autocomplete="organization"></div></div>
<div class="form-row"><div class="field"><label for="email">Email *</label><input required id="email" name="email" type="email" autocomplete="email"></div><div class="field"><label for="phone">Phone</label><input id="phone" name="phone" type="tel" autocomplete="tel"></div></div>
<div class="field"><label for="service">Service required *</label><select required id="service" name="service"><option value="">Select a service</option><option>Website development</option><option>App development</option><option>Corporate branding</option><option>AI automation</option><option>AI video creation and editing</option><option>Other inquiries</option></select></div>
<div class="form-row"><div class="field"><label for="budget">Estimated budget</label><select id="budget" name="budget"><option value="">Select if known</option><option>Not sure yet</option><option>Small project</option><option>Medium project</option><option>Large / ongoing engagement</option></select></div><div class="field"><label for="timeline">Project timeline</label><select id="timeline" name="timeline"><option value="">Select if known</option><option>Flexible</option><option>Within 1 month</option><option>1–3 months</option><option>3+ months</option></select></div></div>
<div class="field"><label for="project_description">Project description *</label><textarea required id="project_description" name="project_description" placeholder="What are you trying to build, improve or automate?"></textarea></div>
<button class="btn btn-primary" type="submit">Send Project Inquiry</button>
</form>
</div>
</div></section>
</main>
<?php get_footer(); ?>
