<?php get_header(); ?>
<main id="main-content">
<section class="page-hero"><div class="container"><span class="eyebrow">Our Products</span><h1>Digital products built to solve real problems.</h1><p>Dot Edge Innovations Ltd is the parent company behind a growing portfolio of digital products. These products retain their own identities and destinations while being connected to Dot Edge through ownership and purpose.</p></div></section>
<section class="section"><div class="container">
<div class="products products-editorial">
<article class="product-feature product-feature-editorial">
  <div class="product-logo-wrap product-logo-billvault"><img src="<?php echo esc_url(dot_edge_asset('billvault-logo.png')); ?>" alt="BillVault logo" class="product-logo billvault-logo"></div>
  <div class="product-copy"><span class="product-badge">Dot Edge product · Digital financial services</span><h3>BillVault</h3><p>BillVault is a digital financial services platform developed by Dot Edge Innovations Ltd, designed to simplify everyday financial transactions. It brings together digital payments, money transfers, bill payments and other financial services in one convenient platform.</p><a class="btn btn-primary" href="https://billvault.app/" target="_blank" rel="noopener noreferrer">Visit BillVault <span aria-hidden="true">↗</span></a></div>
</article>
<article class="product-mini product-mini-editorial">
  <div class="product-logo-wrap product-logo-bvbooks"><img src="<?php echo esc_url(dot_edge_asset('bvbooks-logo.png')); ?>" alt="BVBooks logo" class="product-logo bvbooks-logo"></div>
  <div class="product-copy"><span class="eyebrow">Dot Edge product</span><h3>BVBooks</h3><p>BVBooks is a retail business management platform designed to simplify how businesses manage their operations. By bringing inventory management, sales activities and point-of-sale workflows into a unified system, BVBooks helps businesses improve operational organisation, manage stock more effectively and streamline everyday retail processes.</p><a class="btn btn-secondary" href="https://bvbooks.net/" target="_blank" rel="noopener noreferrer">Visit BVBooks <span aria-hidden="true">↗</span></a></div>
</article>
<article class="product-mini product-mini-editorial product-menu-card">
  <div class="product-logo-wrap product-logo-menu"><img src="<?php echo esc_url(dot_edge_asset('digital-menu-logo.png')); ?>" alt="Digital Menu — Simple Menus. Smarter Dining. logo" class="product-logo digital-menu-logo"></div>
  <div class="product-copy"><span class="eyebrow">Built by Dot Edge Creative Studio</span><h3>DIGITAL MENU &amp; ORDERING SYSTEM</h3><p>A custom-built digital menu and online ordering platform for hotels, restaurants, bars, grills, cafés, coffee shops and other hospitality businesses. Customers can browse menus, explore available items and place orders conveniently from their phones, while businesses can receive and manage incoming orders more efficiently. It keeps menus accessible and makes ordering easier for customers, 24/7.</p><a class="btn btn-secondary" href="https://www.dotedgecreative.org/" target="_blank" rel="noopener noreferrer">Explore Dot Edge Creative <span aria-hidden="true">↗</span></a></div>
</article>
</div>
</div></section>
<section class="section alt"><div class="container"><div class="cta"><div><h2>Need something built for your business?</h2><p>We can discuss a custom digital product, website, application or automation project.</p></div><a class="btn btn-primary" href="<?php echo esc_url(home_url('/contact/')); ?>">Start a Project</a></div></div></section>
</main>
<?php get_footer(); ?>
