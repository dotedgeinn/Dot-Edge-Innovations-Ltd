<?php if (!defined('ABSPATH')) exit; ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#main-content"><?php esc_html_e('Skip to content','dot-edge'); ?></a>
<header class="site-header glass-nav">
  <div class="container header-inner">
    <?php dot_edge_logo(); ?>
    <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="primary-navigation"><span class="menu-icon" aria-hidden="true"><i></i><i></i><i></i></span><span class="menu-label">Menu</span></button>
    <nav id="primary-navigation" class="main-nav" aria-label="<?php esc_attr_e('Primary navigation','dot-edge'); ?>">
      <?php
      if (has_nav_menu('primary')) {
          wp_nav_menu(array('theme_location'=>'primary','container'=>false,'fallback_cb'=>false));
      } else {
          $services_page = get_page_by_path('services');
          $products_page = get_page_by_path('products');
          $about_page = get_page_by_path('about');
          $contact_page = get_page_by_path('contact');
          $items = array(
              home_url('/') => 'Home',
              ($services_page ? get_permalink($services_page) : home_url('/#services')) => 'Services',
              ($products_page ? get_permalink($products_page) : home_url('/#products')) => 'Products',
              ($about_page ? get_permalink($about_page) : home_url('/#about')) => 'About',
              ($contact_page ? get_permalink($contact_page) : home_url('/#contact')) => 'Contact'
          );
          foreach ($items as $url=>$label) {
              echo '<a href="'.esc_url($url).'">'.esc_html($label).'</a>';
          }
      }
      ?>
      <a class="btn btn-primary" href="<?php echo esc_url(home_url('/contact/')); ?>">Start a Project</a>
    </nav>
  </div>
</header>
