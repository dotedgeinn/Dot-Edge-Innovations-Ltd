document.addEventListener('DOMContentLoaded',function(){
 const button=document.querySelector('.menu-toggle');
 const nav=document.querySelector('#primary-navigation');
 if(!button||!nav)return;
 function close(){nav.classList.remove('is-open');button.setAttribute('aria-expanded','false');}
 button.addEventListener('click',function(){const open=nav.classList.toggle('is-open');button.setAttribute('aria-expanded',open?'true':'false');});
 nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',close));
 document.addEventListener('keydown',e=>{if(e.key==='Escape')close();});
 document.addEventListener('click',e=>{if(window.innerWidth<=900 && nav.classList.contains('is-open') && !nav.contains(e.target) && !button.contains(e.target))close();});
 window.addEventListener('resize',()=>{if(window.innerWidth>900)close();});
});
