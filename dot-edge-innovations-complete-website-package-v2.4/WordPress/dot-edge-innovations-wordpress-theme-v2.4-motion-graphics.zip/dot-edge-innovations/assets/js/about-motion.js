(function(){
  document.documentElement.classList.add('js-motion');
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.documentElement.classList.remove('js-motion');
    return;
  }
  var items=document.querySelectorAll('.reveal-on-scroll');
  if(!items.length) return;
  if(!('IntersectionObserver' in window)){items.forEach(function(el){el.classList.add('is-visible')});return;}
  var observer=new IntersectionObserver(function(entries){entries.forEach(function(entry){if(entry.isIntersecting){entry.target.classList.add('is-visible');observer.unobserve(entry.target);}})},{threshold:.12,rootMargin:'0px 0px -30px 0px'});
  items.forEach(function(el){observer.observe(el)});
})();
