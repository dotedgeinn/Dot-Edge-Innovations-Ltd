<?php
if (!defined('ABSPATH')) exit;

define('DOT_EDGE_VERSION', '1.8.0');

function dot_edge_asset($file) {
    return get_theme_file_uri('/assets/'.ltrim($file, '/'));
}

function dot_edge_asset_version($file) {
    $path = get_theme_file_path('/assets/'.ltrim($file, '/'));
    return file_exists($path) ? (string) filemtime($path) : DOT_EDGE_VERSION;
}

function dot_edge_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
    add_theme_support('responsive-embeds');
    add_theme_support('wp-block-styles');
    add_theme_support('align-wide');
    register_nav_menus(array('primary' => __('Primary Menu', 'dot-edge')));
    add_image_size('dot-edge-card', 900, 600, true);
}
add_action('after_setup_theme','dot_edge_setup');

/**
 * Provision the core site pages on theme activation and make Home the static front page.
 * Existing pages are reused; this does not overwrite page content.
 */
function dot_edge_provision_core_pages() {
    $pages = array(
        'home' => array('title'=>'Home', 'template'=>'front-page.php'),
        'about' => array('title'=>'About', 'template'=>'page-about.php'),
        'services' => array('title'=>'Services', 'template'=>'page-services.php'),
        'products' => array('title'=>'Products', 'template'=>'page-products.php'),
        'contact' => array('title'=>'Contact', 'template'=>'page-contact.php'),
    );
    $created = array();
    foreach ($pages as $slug=>$config) {
        $page = get_page_by_path($slug);
        if (!$page) {
            $id = wp_insert_post(array(
                'post_title' => $config['title'],
                'post_name' => $slug,
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_content' => '',
            ), true);
            if (!is_wp_error($id)) {
                $page = get_post($id);
                $created[] = $id;
            }
        }
        if ($page && $slug !== 'home' && !empty($config['template'])) {
            update_post_meta($page->ID, '_wp_page_template', $config['template']);
        }
        if ($slug === 'home' && $page) {
            $home_id = (int) $page->ID;
        }
    }
    if (!empty($home_id)) {
        update_option('show_on_front','page');
        update_option('page_on_front',$home_id);
    }
    update_option('dot_edge_core_pages_version','1.5.0');
}
add_action('after_switch_theme','dot_edge_provision_core_pages');

/**
 * Keep the theme resilient if the site was activated before core pages existed.
 * This only provisions missing pages once per theme version and never overwrites content.
 */
function dot_edge_maybe_provision_core_pages() {
    if (get_option('dot_edge_core_pages_version') !== DOT_EDGE_VERSION) {
        dot_edge_provision_core_pages();
    }
}
add_action('admin_init','dot_edge_maybe_provision_core_pages');

function dot_edge_assets() {
    wp_enqueue_style('dot-edge-fonts','https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap',array(),null);
    wp_enqueue_style('dot-edge-style', get_stylesheet_uri(), array(), file_exists(get_theme_file_path('style.css')) ? filemtime(get_theme_file_path('style.css')) : DOT_EDGE_VERSION);
    wp_enqueue_script('dot-edge-nav', dot_edge_asset('js/navigation.js'), array(), DOT_EDGE_VERSION, true);
    wp_enqueue_script('dot-edge-motion', dot_edge_asset('js/motion.js'), array(), DOT_EDGE_VERSION, true);
    if (is_page('about')) wp_enqueue_script('dot-edge-about-motion', dot_edge_asset('js/about-motion.js'), array(), DOT_EDGE_VERSION, true);
}
add_action('wp_enqueue_scripts','dot_edge_assets');

function dot_edge_favicon() {
    $icon = dot_edge_asset('favicon.png');
    echo '<link rel="icon" href="'.esc_url($icon).'" type="image/png">' . "\n";
}
add_action('wp_head','dot_edge_favicon');

function dot_edge_logo() {
    $logo = dot_edge_asset('dot-edge-logo.png');
    echo '<a class="brand" href="'.esc_url(home_url('/')).'" aria-label="'.esc_attr(get_bloginfo('name')).'"><img src="'.esc_url($logo).'" alt="'.esc_attr(get_bloginfo('name')).'"></a>';
}

function dot_edge_product_url($product) {
    $urls = array(
        'billvault' => 'https://billvault.app/',
        'bvbooks' => 'https://bvbooks.net/',
    );
    return isset($urls[$product]) ? $urls[$product] : '';
}

function dot_edge_contact_form() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['dot_edge_contact_nonce'])) return;
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dot_edge_contact_nonce'])),'dot_edge_contact')) return;
    if (!empty($_POST['website'])) return;

    $name = sanitize_text_field(wp_unslash($_POST['full_name'] ?? ''));
    $business = sanitize_text_field(wp_unslash($_POST['business_name'] ?? ''));
    $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
    $phone = sanitize_text_field(wp_unslash($_POST['phone'] ?? ''));
    $service = sanitize_text_field(wp_unslash($_POST['service'] ?? ''));
    $budget = sanitize_text_field(wp_unslash($_POST['budget'] ?? ''));
    $timeline = sanitize_text_field(wp_unslash($_POST['timeline'] ?? ''));
    $description = sanitize_textarea_field(wp_unslash($_POST['project_description'] ?? ''));

    $errors = array();
    if (!$name) $errors[] = 'Please enter your full name.';
    if (!is_email($email)) $errors[] = 'Please enter a valid email address.';
    if (!$service) $errors[] = 'Please select a service.';
    if (!$description) $errors[] = 'Please tell us a little about the project.';

    if ($errors) {
        set_transient('dot_edge_form_errors', $errors, 60);
        set_transient('dot_edge_form_old', compact('name','business','email','phone','service','budget','timeline','description'), 60);
        wp_safe_redirect(wp_get_referer() ?: home_url('/contact/'));
        exit;
    }

    $to = get_option('admin_email');
    $subject = 'New Dot Edge project inquiry — '.$service;
    $body = "Name: $name\nBusiness: $business\nEmail: $email\nPhone: $phone\nService: $service\nBudget: $budget\nTimeline: $timeline\n\nProject description:\n$description";
    $headers = array('Content-Type: text/plain; charset=UTF-8','Reply-To: '.$email);

    $sent = wp_mail($to,$subject,$body,$headers);
    set_transient('dot_edge_form_status', $sent ? 'success' : 'error', 60);
    wp_safe_redirect(wp_get_referer() ?: home_url('/contact/'));
    exit;
}
add_action('template_redirect','dot_edge_contact_form');

function dot_edge_get_form_status() {
    $status = get_transient('dot_edge_form_status');
    if ($status) delete_transient('dot_edge_form_status');
    return $status;
}
function dot_edge_get_form_errors() {
    $errors = get_transient('dot_edge_form_errors');
    if ($errors) delete_transient('dot_edge_form_errors');
    return $errors ?: array();
}

/* About page SEO + organization schema. Avoids common SEO plugins to prevent duplicate metadata. */
function dot_edge_about_seo_enabled() {
    return is_page('about') && !defined('WPSEO_VERSION') && !defined('RANK_MATH_VERSION') && !defined('AIOSEO_VERSION');
}
function dot_edge_about_document_title($parts) {
    if (dot_edge_about_seo_enabled()) $parts['title'] = 'About Dot Edge Innovations Ltd | Technology & Digital Innovation';
    return $parts;
}
add_filter('document_title_parts','dot_edge_about_document_title');
function dot_edge_about_meta() {
    if (!dot_edge_about_seo_enabled()) return;
    echo '<meta name="description" content="Discover Dot Edge Innovations Ltd, a technology and digital solutions company building innovative products, business platforms, digital financial solutions, and creative experiences.">' . "\n";
    echo '<link rel="canonical" href="'.esc_url(home_url('/about/')).'">' . "\n";
    $logo = dot_edge_asset('dot-edge-logo.png');
    $data = array(
        '@context' => 'https://schema.org',
        '@graph' => array(
            array('@type'=>'Organization','name'=>'Dot Edge Innovations Ltd','url'=>home_url('/'),'logo'=>$logo,'identifier'=>array('@type'=>'PropertyValue','propertyID'=>'RC','value'=>'8542537')),
            array('@type'=>'WebPage','name'=>'About Dot Edge Innovations Ltd','url'=>home_url('/about/'),'description'=>'Discover Dot Edge Innovations Ltd, a technology and digital solutions company building innovative products, business platforms, digital financial solutions, and creative experiences.','isPartOf'=>array('@type'=>'WebSite','url'=>home_url('/'),'name'=>'Dot Edge Innovations Ltd'))
        )
    );
    echo '<script type="application/ld+json">'.wp_json_encode($data, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE).'</script>' . "\n";
}
add_action('wp_head','dot_edge_about_meta',20);
