<?php
/** Template Name: Home */
// Keep the editable Home page aligned with the site's front-page template.
require get_theme_file_path('/front-page.php');
