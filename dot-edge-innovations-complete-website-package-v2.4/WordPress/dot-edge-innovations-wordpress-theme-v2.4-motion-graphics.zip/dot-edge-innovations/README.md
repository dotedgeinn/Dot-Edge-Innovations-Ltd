# Dot Edge Innovations Ltd WordPress Theme

Version 1.5.0

A lightweight WordPress theme for Dot Edge Innovations Ltd. The theme presents Dot Edge as a parent technology and digital innovation company, not only as a software agency.

## Included pages/templates
- Home (`front-page.php`)
- About (`page-about.php`)
- Services (`page-services.php`)
- Products (`page-products.php`)
- Contact (`page-contact.php`)
- Generic page fallback (`page.php`)

## About page
The About page includes the approved corporate positioning and complete content covering:
- Technology and software development
- Digital financial solutions
- Business management technology
- Creative and digital experiences
- Purposeful innovation
- User-centred thinking
- Quality and reliability
- Continuous improvement
- Vision and mission
- Parent-company ecosystem positioning
- BillVault and BVBooks product destinations
- Partnership and project CTAs

## Product destinations
- BillVault: https://billvault.app/
- BVBooks: https://bvbooks.net/

## Brand assets
Use the supplied Dot Edge logo assets in `assets/`. Do not replace or redraw the approved logo.

## Installation
1. In WordPress, go to Appearance > Themes > Add New > Upload Theme.
2. Upload the theme ZIP and activate it.
3. Install the companion Dot Edge Core plugin if supplied with the project.
4. Create pages with slugs `about`, `services`, `products`, and `contact` if they do not already exist.
5. Set the About page template/page slug so `page-about.php` is used automatically.
6. Assign a Primary Menu under Appearance > Menus.
7. Configure WordPress SMTP before relying on project-inquiry email delivery.

## SEO
The theme includes About-page title, description, canonical and Organization/WebPage structured data when no major SEO plugin is active. If Yoast, Rank Math or AIOSEO is active, their metadata remains authoritative to avoid duplicates.

## Production safety
No DNS, hosting, production content or live deployment is performed by this package. Back up the production site before deployment and test the contact form, navigation, responsive layout and product links on staging first.

## Home page
The theme includes a complete `front-page.php` home experience and a `page-home.php` template. On activation, the theme safely creates missing Home, About, Services, Products and Contact pages and assigns Home as the static front page. Existing pages/content are reused and are not overwritten.


## Digital / Online Menu
The Products section includes Digital / Online Menu, a custom hospitality web application built by Dot Edge Creative Studio for hotels, restaurants, bars, grills, cafés, coffee shops and other businesses. The product card links to the Dot Edge Creative Studio website at https://www.dotedgecreative.org/.


Version 1.7.0: clarified Digital / Online Menu product positioning across the homepage, Products page and About ecosystem. The product is described as a custom-built hospitality web application that keeps business menus in customers’ pockets 24/7, built by Dot Edge Creative Studio.


## Version 1.8.0 — Premium UI/UX and motion refinement
- Added a refined scroll progress indicator and header scroll state.
- Enhanced scroll-reveal timing, hover lift, button feedback, and subtle editorial ring details.
- Added reduced-motion support and kept interactions lightweight and accessible.
