<?php if (!defined('ABSPATH')) exit; ?>
<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div>
        <img class="footer-logo" src="<?php echo esc_url(dot_edge_asset('dot-edge-logo-white.png')); ?>" alt="Dot Edge Innovations Ltd">
        <p>Dot Edge Innovations Ltd builds products, platforms and creative solutions that help businesses operate, grow and compete.</p>
        <p><strong>IDEAS | SOLUTIONS | IMPACT</strong></p>
      </div>
      <div>
        <h3>Explore</h3>
        <?php
        $services_page = get_page_by_path('services');
        $products_page = get_page_by_path('products');
        $about_page = get_page_by_path('about');
        $services_url = $services_page ? get_permalink($services_page) : home_url('/#services');
        $products_url = $products_page ? get_permalink($products_page) : home_url('/#products');
        $about_url = $about_page ? get_permalink($about_page) : home_url('/#about');
        ?>
        <p><a href="<?php echo esc_url($services_url); ?>">Services</a></p>
        <p><a href="<?php echo esc_url($products_url); ?>">Products</a></p>
        <p><a href="<?php echo esc_url($about_url); ?>">About</a></p>
      </div>
      <div>
        <h3>Capabilities</h3>
        <p><a href="<?php echo esc_url(home_url('/services/#development')); ?>">Web & App Development</a></p>
        <p><a href="<?php echo esc_url(home_url('/services/#creative')); ?>">Branding & Creative</a></p>
        <p><a href="<?php echo esc_url(home_url('/services/#ai')); ?>">AI & Automation</a></p>
      </div>
      <div>
        <h3>Start a conversation</h3>
        <p>Tell us what you want to build, improve or automate.</p>
        <p><a class="btn btn-primary" href="<?php echo esc_url(home_url('/contact/')); ?>">Start a Project</a></p>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <?php echo esc_html(date('Y')); ?> Dot Edge Innovations Ltd. RC 8542537.</span>
      <span>Nigeria · Built around practical digital solutions.</span>
    </div>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
