<?php get_header(); ?>
<?php if (!defined('ABSPATH')) exit; ?>
<main id="main-content" class="about-page">
  <section class="about-hero">
    <div class="container about-hero-grid">
      <div class="about-hero-copy reveal-on-scroll">
        <span class="eyebrow">About Dot Edge</span>
        <h1>We Build Technology That Moves Businesses Forward.</h1>
        <p class="hero-lead">Dot Edge Innovations Ltd is a technology and digital solutions company focused on building innovative products, creating meaningful digital experiences, and developing solutions that help businesses solve real-world problems.</p>
        <p>We combine technology, creativity, and business thinking to transform ideas into practical solutions. From digital financial services and business management platforms to creative digital services, we work at the intersection of innovation and opportunity.</p>
        <p>Our goal is simple: to make technology more useful, businesses more efficient, and digital opportunities more accessible.</p>
        <div class="hero-actions">
          <a class="btn btn-primary" href="<?php echo esc_url(home_url('/services/')); ?>">Explore Our Solutions <span aria-hidden="true">→</span></a>
          <a class="btn btn-secondary" href="<?php echo esc_url(home_url('/contact/')); ?>">Partner With Us</a>
        </div>
      </div>
      <div class="about-hero-media reveal-on-scroll">
        <img src="<?php echo esc_url(dot_edge_asset('about-hero.jpg')); ?>" alt="Small technology team collaborating around a laptop in a contemporary workspace" width="1536" height="1024" loading="eager" fetchpriority="high">
      </div>
    </div>
  </section>

  <section class="section about-who">
    <div class="container about-split about-split-reverse">
      <div class="about-media reveal-on-scroll">
        <img src="<?php echo esc_url(dot_edge_asset('about-who-we-are.jpg')); ?>" alt="Technology professional thoughtfully reviewing a digital product at a desk" width="1448" height="1086" loading="lazy">
      </div>
      <div class="about-copy reveal-on-scroll">
        <span class="eyebrow">Who We Are</span>
        <h2>We are a technology-driven company with a practical approach to innovation.</h2>
        <p>We believe great technology should do more than look impressive. It should solve problems, simplify processes, create value, and deliver meaningful results.</p>
        <p>At Dot Edge Innovations, we identify opportunities, develop solutions, and build digital products around the needs of the people and businesses they serve.</p>
        <p>Our work spans multiple areas of the digital economy, allowing us to explore new ideas, develop specialised solutions, and build brands that address different market needs while sharing one commitment to quality, usability, and continuous improvement.</p>
      </div>
    </div>
  </section>

  <section class="section about-capabilities">
    <div class="container">
      <div class="section-head about-section-head">
        <div>
          <span class="eyebrow">What We Do</span>
          <h2>Building solutions across the digital economy.</h2>
        </div>
      </div>
      <div class="about-capabilities-grid">
        <div class="about-capability-cards">
          <article class="card about-capability reveal-on-scroll">
            <div class="icon-box" aria-hidden="true">01</div>
            <h3>Technology &amp; Software Development</h3>
            <p>We design and develop digital products, software platforms, and technology solutions that help businesses streamline operations, improve productivity, and unlock new opportunities.</p>
          </article>
          <article class="card about-capability reveal-on-scroll">
            <div class="icon-box" aria-hidden="true">02</div>
            <h3>Digital Financial Solutions</h3>
            <p>Through our digital products, we explore smarter ways to manage payments, access financial services, and simplify everyday financial transactions.</p>
          </article>
          <article class="card about-capability reveal-on-scroll">
            <div class="icon-box" aria-hidden="true">03</div>
            <h3>Business Management Technology</h3>
            <p>We build solutions that help businesses gain better control over their operations, manage resources, improve visibility, and make more informed decisions.</p>
          </article>
          <article class="card about-capability reveal-on-scroll">
            <div class="icon-box" aria-hidden="true">04</div>
            <h3>Creative &amp; Digital Experiences</h3>
            <p>Through our creative services, we develop visual content, digital advertising, brand experiences, and communication assets that help businesses connect with their audiences and strengthen their digital presence.</p>
          </article>
        </div>
        <div class="about-media about-capability-media reveal-on-scroll">
          <img src="<?php echo esc_url(dot_edge_asset('about-what-we-do.jpg')); ?>" alt="Laptop and smartphone used for digital product work on a professional desk" width="1448" height="1086" loading="lazy">
        </div>
      </div>
    </div>
  </section>

  <section class="section about-approach">
    <div class="container">
      <div class="about-approach-intro reveal-on-scroll">
        <span class="eyebrow">Our Approach</span>
        <h2>We believe innovation begins with understanding the problem.</h2>
        <p>Every solution starts with a clear purpose: understanding the needs of users, identifying opportunities for improvement, and developing practical ways to deliver value.</p>
        <p>Our approach is built around four principles.</p>
      </div>
      <div class="about-principles">
        <article class="about-principle reveal-on-scroll"><span class="principle-icon" aria-hidden="true">01</span><h3>Purposeful Innovation</h3><p>We focus on ideas and technologies that address genuine needs.</p></article>
        <article class="about-principle reveal-on-scroll"><span class="principle-icon" aria-hidden="true">02</span><h3>User-Centred Thinking</h3><p>We prioritise usability, accessibility, and meaningful experiences.</p></article>
        <article class="about-principle reveal-on-scroll"><span class="principle-icon" aria-hidden="true">03</span><h3>Quality &amp; Reliability</h3><p>We strive to build solutions that are dependable, scalable, and fit for purpose.</p></article>
        <article class="about-principle reveal-on-scroll"><span class="principle-icon" aria-hidden="true">04</span><h3>Continuous Improvement</h3><p>We embrace learning, experimentation, and emerging technologies to keep moving forward.</p></article>
      </div>
    </div>
  </section>

  <section class="section about-vision-mission">
    <div class="container about-vm-grid">
      <article class="about-vm-card reveal-on-scroll"><span class="eyebrow">Our Vision</span><h2>Our Vision</h2><p>To become a recognised technology and innovation company, building impactful digital products and solutions that empower businesses, improve everyday experiences, and create opportunities across emerging and global markets.</p></article>
      <article class="about-vm-card reveal-on-scroll"><span class="eyebrow">Our Mission</span><h2>Our Mission</h2><p>To transform ideas into practical technology and digital solutions that solve real problems, create lasting value, and help individuals and businesses thrive in an increasingly connected world.</p></article>
    </div>
  </section>

  <section class="section about-ecosystem">
    <div class="container about-ecosystem-grid">
      <div class="about-media reveal-on-scroll">
        <img src="<?php echo esc_url(dot_edge_asset('about-ecosystem.jpg')); ?>" alt="Professional working across digital products on a laptop and smartphone in a real workspace" width="1536" height="1024" loading="lazy">
      </div>
      <div class="about-copy reveal-on-scroll">
        <span class="eyebrow">Our Growing Ecosystem</span>
        <h2>A parent company building a growing portfolio of products, services, and brands.</h2>
        <p>Dot Edge Innovations Ltd serves as the parent company behind a growing portfolio of digital products, services, and brands.</p>
        <p>Each brand is built around a distinct purpose and audience, united by our broader commitment to innovation, functionality, and value creation.</p>
        <p>We see every product as an opportunity to solve a problem, every service as an opportunity to make a difference, and every new idea as a chance to move technology forward.</p>
        <div class="about-products-mini">
          <a class="about-product-mini" href="https://billvault.app/" target="_blank" rel="noopener noreferrer"><strong>BillVault</strong><span>Digital financial services</span><em>Visit BillVault →</em></a>
          <a class="about-product-mini" href="https://bvbooks.net/" target="_blank" rel="noopener noreferrer"><strong>BVBooks</strong><span>Business management technology</span><em>Visit BVBooks →</em></a>
          <a class="about-product-mini" href="https://www.dotedgecreative.org/" target="_blank" rel="noopener noreferrer"><strong>DIGITAL MENU &amp; ORDERING SYSTEM</strong><span>Custom-built hospitality web application · Keeps menus in customers’ pockets 24/7 · Built by Dot Edge Creative Studio</span><em>Explore Dot Edge Creative →</em></a>
        </div>
      </div>
    </div>
  </section>

  <section class="section about-closing">
    <div class="container">
      <div class="about-closing-panel reveal-on-scroll">
        <div>
          <span class="eyebrow">Let's Build What's Next.</span>
          <h2>Let's Build What's Next.</h2>
          <p>We believe the future belongs to those who turn ideas into meaningful action.</p>
          <p>Whether you are a business seeking a technology solution, an organisation looking to strengthen its digital capabilities, or a potential partner exploring new opportunities, Dot Edge Innovations Ltd is ready to connect.</p>
          <p>Let's turn ideas into solutions and possibilities into progress.</p>
          <div class="hero-actions">
            <a class="btn btn-primary" href="<?php echo esc_url(home_url('/services/')); ?>">Explore Our Solutions <span aria-hidden="true">→</span></a>
            <a class="btn btn-secondary" href="<?php echo esc_url(home_url('/contact/')); ?>">Contact Us</a>
          </div>
        </div>
        <div class="about-closing-media"><img src="<?php echo esc_url(dot_edge_asset('about-closing.jpg')); ?>" alt="Small team in conversation while reviewing a project together" width="1536" height="864" loading="lazy"></div>
      </div>
    </div>
  </section>
</main>
<?php get_footer(); ?>
