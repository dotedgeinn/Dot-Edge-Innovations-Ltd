<?php get_header(); ?>
<main id="main-content">
  <section class="page-hero">
    <div class="container">
      <span class="eyebrow">Dot Edge Innovations Ltd</span>
      <h1><?php the_title(); ?></h1>
    </div>
  </section>
  <section class="section">
    <div class="container prose">
      <?php while (have_posts()) : the_post(); the_content(); endwhile; ?>
    </div>
  </section>
</main>
<?php get_footer(); ?>
