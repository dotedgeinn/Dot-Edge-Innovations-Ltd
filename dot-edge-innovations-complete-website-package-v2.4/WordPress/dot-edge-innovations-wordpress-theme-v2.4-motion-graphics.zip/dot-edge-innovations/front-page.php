<?php get_header(); ?>
<main id="main-content">
<section class="hero hero-tech">
  <div class="tech-grid" aria-hidden="true"></div><div class="orb orb-one" aria-hidden="true"></div><div class="orb orb-two" aria-hidden="true"></div>
  <div class="container hero-grid">
    <div>
      <div class="eyebrow">IDEAS | SOLUTIONS | IMPACT</div>
      <h1>We turn ideas into digital products that move businesses forward.</h1>
      <p>We build products, platforms and creative solutions that help businesses operate, grow and compete. From digital financial services and business management technology to websites, applications, branding and practical AI automation, we combine technology, creativity and business thinking to turn ideas into useful outcomes.</p>
      <div class="hero-actions">
        <a class="btn btn-primary" href="<?php echo esc_url(home_url('/contact/')); ?>">Start a Project</a>
        <a class="btn btn-secondary" href="<?php echo esc_url(home_url('/services/')); ?>">Explore Our Services</a>
      </div>
    </div>
    <div class="hero-art" aria-label="Illustrative digital product interface">
      <div class="dashboard glass-panel" data-tilt>
        <div class="dashboard-top"><span></span><span></span><span></span></div>
        <div class="dashboard-grid">
          <div>
            <div class="mock-card dark"><small>Digital products</small><div class="mock-number" style="color:#84D141">Build</div><p style="color:#d7e3ec">Websites, apps and software shaped around real business needs.</p></div>
            <div class="mock-card" style="margin-top:14px"><strong style="color:#0B2D4F">Brand systems</strong><div class="mock-line"></div><div class="mock-line short"></div></div>
          </div>
          <div>
            <div class="mock-card"><small>Automation</small><h3 style="color:#0B2D4F">Smarter workflows</h3><p style="font-size:13px">Practical AI and connected processes.</p><div class="mock-line"></div><div class="mock-line"></div></div>
            <div class="mock-card" style="margin-top:14px;background:#edf9f1"><strong style="color:#0B2D4F">BillVault</strong><p style="font-size:13px">A Dot Edge product.</p></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section">
<div class="container">
  <div class="section-head"><div><span class="eyebrow">What we do</span><h2>Technology, creativity and AI—connected around your goals.</h2></div></div>
  <div class="cards">
    <article class="card glass-card" id="development" data-tilt><div class="icon-box">01</div><h3>Digital Product Development</h3><p>Professional websites, web applications, mobile applications, SaaS products and custom digital solutions.</p><ul><li>Business websites</li><li>Web applications</li><li>Mobile applications</li><li>SaaS & MVPs</li><li>Business software & integrations</li></ul><a class="link-arrow" href="<?php echo esc_url(home_url('/services/')); ?>">Explore Development →</a></article>
    <article class="card glass-card" id="creative" data-tilt><div class="icon-box">02</div><h3>Creative & Brand Identity</h3><p>Distinctive brand identities and creative communication that help businesses present themselves clearly.</p><ul><li>Logo design</li><li>Brand identity systems</li><li>Marketing creatives</li><li>Social media design</li><li>AI video creation & editing</li></ul><a class="link-arrow" href="<?php echo esc_url(home_url('/services/#creative')); ?>">Explore Creative Services →</a></article>
    <article class="card glass-card" id="ai" data-tilt><div class="icon-box">03</div><h3>AI & Business Automation</h3><p>Practical AI implementation, workflow automation and intelligent integrations where they provide useful value.</p><ul><li>Workflow automation</li><li>AI-assisted processes</li><li>Intelligent integrations</li><li>AI content workflows</li><li>AI video production workflows</li></ul><a class="link-arrow" href="<?php echo esc_url(home_url('/services/#ai')); ?>">Explore AI Solutions →</a></article>
  </div>
</div>
</section>

<section class="section alt">
<div class="container">
  <div class="section-head"><div><span class="eyebrow">Our products</span><h2>Digital products built to solve real problems.</h2><p class="section-lead">Dot Edge Innovations Ltd also develops and owns digital products. BillVault is presented here as a company product—not as client work.</p></div><a class="btn btn-secondary" href="<?php echo esc_url(home_url('/products/')); ?>">View Products</a></div>
  <div class="products products-editorial">
    <article class="product-feature product-feature-editorial">
      <div class="product-logo-wrap product-logo-billvault"><img src="<?php echo esc_url(dot_edge_asset('billvault-logo.png')); ?>" alt="BillVault logo" class="product-logo billvault-logo"></div>
      <div class="product-copy">
        <span class="product-badge">Dot Edge product · Digital financial services</span>
        <h3>BillVault</h3>
        <p>BillVault is a digital financial services platform developed by Dot Edge Innovations Ltd, designed to simplify everyday financial transactions. It brings together digital payments, money transfers, bill payments and other financial services in one convenient platform.</p>
        <a class="btn btn-primary" href="https://billvault.app/" target="_blank" rel="noopener noreferrer">Explore BillVault <span aria-hidden="true">↗</span></a>
      </div>
    </article>
    <article class="product-mini product-mini-editorial">
      <div class="product-logo-wrap product-logo-bvbooks"><img src="<?php echo esc_url(dot_edge_asset('bvbooks-logo.png')); ?>" alt="BVBooks logo" class="product-logo bvbooks-logo"></div>
      <div class="product-copy">
        <span class="eyebrow">Dot Edge product</span>
        <h3>BVBooks</h3>
        <p>BVBooks is a retail business management platform designed to simplify how businesses manage their operations. By bringing inventory management, sales activities and point-of-sale workflows into a unified system, BVBooks helps businesses improve operational organisation, manage stock more effectively and streamline everyday retail processes.</p>
        <a class="btn btn-secondary" href="https://bvbooks.net/" target="_blank" rel="noopener noreferrer">Visit BVBooks <span aria-hidden="true">↗</span></a>
      </div>
    </article>
    <article class="product-mini product-mini-editorial product-menu-card">
      <div class="product-logo-wrap product-logo-menu"><img src="<?php echo esc_url(dot_edge_asset('digital-menu-logo.png')); ?>" alt="Digital Menu — Simple Menus. Smarter Dining. logo" class="product-logo digital-menu-logo"></div>
      <div class="product-copy">
        <span class="eyebrow">Built by Dot Edge Creative Studio</span>
        <h3>DIGITAL MENU &amp; ORDERING SYSTEM</h3>
        <p>A custom-built digital menu and online ordering platform for hotels, restaurants, bars, grills, cafés, coffee shops and other hospitality businesses. Customers can browse menus, explore available items and place orders conveniently from their phones, while businesses can receive and manage incoming orders more efficiently. It keeps menus accessible and makes ordering easier for customers, 24/7.</p>
        <a class="btn btn-secondary" href="https://www.dotedgecreative.org/" target="_blank" rel="noopener noreferrer">Explore Dot Edge Creative <span aria-hidden="true">↗</span></a>
      </div>
    </article>
  </div>
</div>
</section>

<section class="section">
<div class="container">
  <div class="section-head"><div><span class="eyebrow">Selected work</span><h2>Practical solutions, built with purpose.</h2><p class="section-lead">Use this section for approved websites, apps, branding, marketing creative and AI video projects. No client claims or performance statistics are published without approval.</p></div></div>
  <div class="work-grid">
    <div class="work-card glass-card" data-tilt><span class="tag">Digital</span><h3>Website / web application</h3><p>Approved project showcase slot.</p></div>
    <div class="work-card glass-card" data-tilt><span class="tag">Product</span><h3>Mobile / SaaS product</h3><p>Approved product showcase slot.</p></div>
    <div class="work-card glass-card" data-tilt><span class="tag">Brand</span><h3>Corporate identity</h3><p>Approved branding showcase slot.</p></div>
  </div>
</div>
</section>

<section class="section alt" id="ecosystem">
<div class="container">
  <div class="section-head"><div><span class="eyebrow">Our ecosystem</span><h2>A parent company building products, services and brands.</h2><p class="section-lead">Dot Edge Innovations Ltd is a parent technology and digital innovation company. We develop our own digital products while providing technology, creative and AI capabilities to businesses and organisations.</p></div></div>
  <div class="cards">
    <article class="card"><div class="icon-box">01</div><h3>Company-owned products</h3><p>We develop and operate digital products such as BillVault and BVBooks, each with its own purpose, audience and identity.</p><a class="link-arrow" href="<?php echo esc_url(home_url('/products/')); ?>">Explore Our Products →</a></article>
    <article class="card"><div class="icon-box">02</div><h3>Technology &amp; digital services</h3><p>We help startups, entrepreneurs, SMEs and established companies turn business needs into practical digital solutions.</p><a class="link-arrow" href="<?php echo esc_url(home_url('/services/')); ?>">Explore Our Services →</a></article>
    <article class="card"><div class="icon-box">03</div><h3>Creative capabilities</h3><p>Through Dot Edge Creative, we connect brand strategy, visual communication, digital advertising and content production.</p><a class="link-arrow" href="<?php echo esc_url(home_url('/services/#creative')); ?>">Explore Creative →</a></article>
  </div>
</div>
</section>

<section class="section blue">
<div class="container">
  <div class="section-head"><div><span class="eyebrow">Our process</span><h2>From first conversation to launch.</h2></div></div>
  <div class="process">
    <?php foreach (array('Discover','Define','Design','Build','Validate','Launch') as $i=>$step): ?>
      <div class="step"><span><?php echo esc_html(sprintf('%02d',$i+1)); ?></span><h3><?php echo esc_html($step); ?></h3><p><?php echo esc_html(array('Understand goals, users and constraints.','Agree scope, priorities and deliverables.','Shape the experience and visual direction.','Develop or produce the solution.','Test functionality, content and usability.','Release, hand over and plan next steps.')[$i]); ?></p></div>
    <?php endforeach; ?>
  </div>
  <p style="margin-top:20px;color:#5a6c7c">Deliverables and timelines depend on project scope.</p>
</div>
</section>

<section class="section">
<div class="container">
  <div class="cta glass-panel"><div><span class="eyebrow" style="color:#84D141">Let's build</span><h2>Have an idea worth building? Let's make it happen.</h2><p>Tell us what you want to build, improve, or automate. Let's explore the right solution for your business.</p></div><a class="btn btn-primary" href="<?php echo esc_url(home_url('/contact/')); ?>">Start a Project</a></div>
</div>
</section>
</main>
<?php get_footer(); ?>
